package com.example.primerproyecto

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.app.Activity


class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        findViewById<TextView>(R.id.welcomeTitle).text = getString(R.string.welcome_title)
        findViewById<Button>(R.id.enterButton).text = getString(R.string.enter_button)
    }
}
