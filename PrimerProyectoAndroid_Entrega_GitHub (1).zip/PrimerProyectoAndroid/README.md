# Mi primer proyecto Android

Proyecto académico de ejemplo desarrollado con **Kotlin y vistas XML**. La aplicación presenta una pantalla de bienvenida y adapta sus textos al idioma del dispositivo.

## Requisitos solicitados

- Idioma predeterminado: español.
- Traducciones: inglés, francés y alemán.
- Interfaz adaptable a orientación vertical y horizontal y a distintos tamaños mediante medidas flexibles (`match_parent`, `wrap_content`, pesos y unidades `dp`/`sp`).
- Fondo gráfico tipo cielo con nubes y recurso Nine-Patch (`fondo_android_nine.9.png`) para permitir el estiramiento del área central sin deformar los bordes.

## Estructura

```text
PrimerProyectoAndroid/
├── app/
│   ├── build.gradle.kts
│   └── src/main/
│       ├── java/com/example/primerproyecto/MainActivity.kt
│       ├── res/layout/activity_main.xml
│       ├── res/drawable/android_mascot.xml
│       ├── res/drawable-nodpi/fondo_android_nine.9.png
│       ├── res/values/strings.xml
│       ├── res/values-en/strings.xml
│       ├── res/values-fr/strings.xml
│       └── res/values-de/strings.xml
├── build.gradle.kts
├── gradle.properties
└── settings.gradle.kts
```

## Abrir en Android Studio

1. Descomprime el ZIP.
2. En Android Studio selecciona **Open** y elige la carpeta raíz `PrimerProyectoAndroid` (la que contiene `settings.gradle.kts`).
3. Espera a que termine la sincronización de Gradle.
4. Si Android Studio solicita instalar Android SDK 35 o herramientas de compilación, acepta la instalación.
5. Selecciona un emulador o dispositivo y ejecuta la configuración `app`.

## Cambiar idioma

La aplicación utiliza los recursos estándar de Android. Cambia el idioma de la aplicación/dispositivo a Español, English, Français o Deutsch para comprobar las cadenas correspondientes.

## Estado de verificación

Los archivos fuente y recursos están organizados en este repositorio. **Este paquete no se ha compilado ni ejecutado en Android Studio en este entorno**, por lo que la compilación, la visualización en dispositivos reales y el comportamiento del Nine-Patch deben verificarse al abrirlo con Android SDK/Gradle instalado. No se afirma que se hayan realizado pruebas instrumentadas.

## Tecnologías

- Kotlin 2.0.21
- Android Gradle Plugin 8.6.1
- compileSdk 35 / minSdk 23
- Layout XML y recursos localizados de Android
